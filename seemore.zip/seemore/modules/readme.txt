seemore.py broken down into separate .py files for modularity
