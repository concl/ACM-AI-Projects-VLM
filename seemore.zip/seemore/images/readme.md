These are the three test images used to test the training loop. Images in base64 encoded string format alongside their descriptions are in the inputs.csv file given here.
